@echo off
chcp 65001 >nul
if not exist "%~dp0uninstall.ps1" (echo Please extract the ZIP file first, then run uninstall.cmd again. & pause & exit /b 1)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0uninstall.ps1"
