﻿# התקנת "הקול החמישי – כיתה" לחשבון של המשתמש שמריץ (התלמיד), בלי הרשאת מנהל.
# מריצים דרך קובץ ההתקנה (kol-kiosk-class-setup.exe) או install.cmd.
# הכול נכתב לחשבון הזה בלבד: התוכנה ב-%LOCALAPPDATA%\KolKiosk, ההגדרות ב-HKCU, קיצור בשולחן העבודה שלו.

$DbUrl = 'https://kol-kiosk-class-default-rtdb.europe-west1.firebasedatabase.app'
Add-Type -AssemblyName System.Windows.Forms, Microsoft.VisualBasic, System.Web.Extensions
$Title = 'הקול החמישי – כיתה'
$Rtl = [System.Windows.Forms.MessageBoxOptions]::RtlReading -bor [System.Windows.Forms.MessageBoxOptions]::RightAlign

function Say([string]$text, [string]$icon = 'Information') {
    [void][System.Windows.Forms.MessageBox]::Show($text, $Title, 'OK', $icon, 'Button1', $Rtl)
}
function AskYesNo([string]$text) {
    return [System.Windows.Forms.MessageBox]::Show($text, $Title, 'YesNo', 'Question', 'Button1', $Rtl) -eq 'Yes'
}
function EnsureKey([string]$path) { if (-not (Test-Path $path)) { New-Item -Path $path -Force | Out-Null } }

try {
    $ErrorActionPreference = 'Stop'
    $src = Join-Path $PSScriptRoot 'KolKiosk.exe'
    if (-not (Test-Path $src)) { throw "הקובץ KolKiosk.exe לא נמצא ליד ההתקנה. חלצו את כל קובץ ה-ZIP לתיקייה ונסו שוב." }

    # ---- התוכנה: לחשבון הזה ----
    Get-Process KolKiosk -ErrorAction SilentlyContinue | Where-Object { $_.SessionId -eq (Get-Process -Id $PID).SessionId } |
        Stop-Process -Force -ErrorAction SilentlyContinue
    Start-Sleep -Milliseconds 500
    $dir = Join-Path $env:LOCALAPPDATA 'KolKiosk'
    $exe = Join-Path $dir 'KolKiosk.exe'
    New-Item -ItemType Directory -Force $dir | Out-Null
    Copy-Item $src $exe -Force
    Unblock-File $exe

    $ws = New-Object -ComObject WScript.Shell
    $lnk = $ws.CreateShortcut((Join-Path ([Environment]::GetFolderPath('Desktop')) 'הקול החמישי - כיתה.lnk'))
    $lnk.TargetPath = $exe
    $lnk.WorkingDirectory = $dir
    $lnk.IconLocation = "$exe,0"
    $lnk.Save()

    # בלי השהיה של תוכנות ההפעלה בכניסה, כדי שהתוכנה תעלה לפני שאפשר לעשות משהו אחר
    $serialize = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Serialize'
    EnsureKey $serialize
    Set-ItemProperty $serialize StartupDelayInMSec 0 -Type DWord

    # ---- קוד כיתה ----
    $code = ''
    $className = ''
    while ($true) {
        $code = [Microsoft.VisualBasic.Interaction]::InputBox(
            "קוד כיתה מלוח הבקרה של המורה (5 ספרות).`n`nמשאירים ריק = בלי שליטת מורה (האתר תמיד פתוח).",
            $Title, $code) -replace '\D', ''
        if (-not $code) { break }
        try {
            [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor 3072
            $r = Invoke-WebRequest -Uri "$DbUrl/classes/$code/state/name.json" -UseBasicParsing -TimeoutSec 20
            $name = (New-Object System.Web.Script.Serialization.JavaScriptSerializer).DeserializeObject([Text.Encoding]::UTF8.GetString($r.RawContentStream.ToArray()))
            if ($name) { $className = [string]$name; break }
            if (-not (AskYesNo "קוד הכיתה $code לא נמצא.`n`nלהקליד קוד אחר?")) { $code = ''; break }
        } catch {
            Say "לא הצלחתי להתחבר לשרת הכיתה כדי לבדוק את הקוד.`nייתכן שאין אינטרנט, או שסינון האינטרנט (רימון, נטפרי וכו') חוסם את firebasedatabase.app.`n`nהקוד יישמר בכל זאת. אם המחשבים יציגו `"אין חיבור לשרת הכיתה`", צריך לבקש מהסינון לפתוח את firebasedatabase.app ואת yudataub.github.io." 'Warning'
            break
        }
    }
    EnsureKey 'HKCU:\Software\KolKiosk'
    Set-ItemProperty 'HKCU:\Software\KolKiosk' ClassCode $code

    # ---- קוד יציאה ----
    # מחשב של כיתה לא צריך קוד משלו: המורה יוצא עם קוד היציאה של הכיתה (מוגדר בלוח הבקרה), או משחרר מהלוח.
    # (קוד שנשמר בחשבון התלמיד התלמיד יכול לשנות, ולכן לכיתה התוכנה לא סומכת עליו.)
    # בלי קוד כיתה (שימוש בבית) – שואלים קוד יציאה, כי בלעדיו אי אפשר לצאת.
    if (-not $code) {
        while ($true) {
            $exitCode = ([Microsoft.VisualBasic.Interaction]::InputBox(
                "קוד יציאה (לפחות 4 ספרות או אותיות).`n`nאיתו יוצאים מהתוכנה: כפתור `"יציאה (מורה)`" או Ctrl+Shift+Q.",
                $Title, '')).Trim()
            if ($exitCode.Length -ge 4) {
                $kdf = New-Object Security.Cryptography.Rfc2898DeriveBytes(
                    [Text.Encoding]::UTF8.GetBytes($exitCode), [Text.Encoding]::UTF8.GetBytes('kolkiosk-local|'), 100000)
                $hex = -join ($kdf.GetBytes(32) | ForEach-Object { $_.ToString('x2') })
                Set-ItemProperty 'HKCU:\Software\KolKiosk' ExitHash $hex
                break
            }
            if (-not $exitCode -and (AskYesNo "בלי קוד יציאה אי אפשר לצאת מהתוכנה.`n`nלבטל את ההתקנה?")) { throw 'ההתקנה בוטלה.' }
            if ($exitCode) { Say 'צריך קוד יציאה של לפחות 4 תווים.' 'Warning' }
        }
    }

    # ---- הפעלה אוטומטית: מחשב של כיתה תמיד; בלי כיתה – שואלים ----
    $run = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
    EnsureKey $run
    if ($code -or (AskYesNo "להפעיל את התוכנה אוטומטית בכל כניסה למחשב?")) {
        Set-ItemProperty $run KolKiosk "`"$exe`""
        $auto = 'התוכנה תיפתח לבד בכל כניסה למחשב.'
    } else {
        Remove-ItemProperty $run KolKiosk -ErrorAction SilentlyContinue
        $auto = 'התוכנה לא תיפתח לבד. פותחים אותה מהקיצור בשולחן העבודה.'
    }

    $cls = if ($className) { "המחשב מחובר לכיתה `"$className`" ($code)." } elseif ($code) { "קוד הכיתה $code נשמר (לא נבדק מול השרת)." } else { 'המחשב יעבוד בלי שליטת מורה.' }
    Say "ההתקנה הסתיימה.`n`n$cls`n$auto`n`nהתוכנה נפתחת עכשיו."
    Start-Process $exe
} catch {
    Say "ההתקנה נכשלה:`n$($_.Exception.Message)" 'Error'
}
