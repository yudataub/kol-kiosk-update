﻿# התקנת "הקול החמישי – כיתה" לחשבון של המשתמש שמריץ (התלמיד), בלי הרשאת מנהל.
# מריצים דרך קובץ ההתקנה (kol-kiosk-class-setup.exe) או install.cmd.
# הכול נכתב לחשבון הזה בלבד: התוכנה ב-%LOCALAPPDATA%\KolKiosk, ההגדרות ב-HKCU, קיצור בשולחן העבודה שלו.

$DbUrl = 'https://kol-kiosk-class-default-rtdb.europe-west1.firebasedatabase.app'
Add-Type -AssemblyName System.Windows.Forms, Microsoft.VisualBasic, System.Web.Extensions
$Title = 'הקול החמישי – כיתה'
$Rtl = [System.Windows.Forms.MessageBoxOptions]::RtlReading -bor [System.Windows.Forms.MessageBoxOptions]::RightAlign

function Say([string]$text, [string]$icon = 'Information') {
    [void][System.Windows.Forms.MessageBox]::Show($text, $Title, 'OK', $icon, 'Button1', $Rtl)
}
function AskYesNo([string]$text) {
    return [System.Windows.Forms.MessageBox]::Show($text, $Title, 'YesNo', 'Question', 'Button1', $Rtl) -eq 'Yes'
}
function EnsureKey([string]$path) { if (-not (Test-Path $path)) { New-Item -Path $path -Force | Out-Null } }

try {
    $ErrorActionPreference = 'Stop'
    $src = Join-Path $PSScriptRoot 'KolKiosk.exe'
    if (-not (Test-Path $src)) { throw "הקובץ KolKiosk.exe לא נמצא ליד ההתקנה. חלצו את כל קובץ ה-ZIP לתיקייה ונסו שוב." }

    # ---- התוכנה: לחשבון הזה ----
    Get-Process KolKiosk -ErrorAction SilentlyContinue | Where-Object { $_.SessionId -eq (Get-Process -Id $PID).SessionId } |
        Stop-Process -Force -ErrorAction SilentlyContinue
    Start-Sleep -Milliseconds 500
    $dir = Join-Path $env:LOCALAPPDATA 'KolKiosk'
    $exe = Join-Path $dir 'KolKiosk.exe'
    New-Item -ItemType Directory -Force $dir | Out-Null
    Copy-Item $src $exe -Force
    Unblock-File $exe

    $ws = New-Object -ComObject WScript.Shell
    $lnk = $ws.CreateShortcut((Join-Path ([Environment]::GetFolderPath('Desktop')) 'הקול החמישי - כיתה.lnk'))
    $lnk.TargetPath = $exe
    $lnk.WorkingDirectory = $dir
    $lnk.IconLocation = "$exe,0"
    $lnk.Save()

    # ---- רכיב הדפדפן של Windows (WebView2): חסר בחלק ממחשבי Windows 10. בלי הרשאת מנהל הוא מותקן לחשבון הזה ----
    $wv = '{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}'
    $hasWv = $false
    foreach ($k in @("HKLM:\SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\$wv", "HKLM:\SOFTWARE\Microsoft\EdgeUpdate\Clients\$wv",
                     "HKCU:\Software\Microsoft\EdgeUpdate\Clients\$wv")) {
        $pv = (Get-ItemProperty $k -Name pv -ErrorAction SilentlyContinue).pv
        if ($pv -and $pv -ne '0.0.0.0') { $hasWv = $true }
    }
    if (-not $hasWv) {
        Say "במחשב הזה חסר רכיב הדפדפן של Windows (WebView2). מתקינים אותו עכשיו – זה לוקח כדקה או שתיים.`n`nלוחצים אישור וממתינים להודעה הבאה."
        try {
            [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor 3072
            $wvSetup = Join-Path $env:TEMP 'MicrosoftEdgeWebview2Setup.exe'
            Invoke-WebRequest -Uri 'https://go.microsoft.com/fwlink/p/?LinkId=2124703' -OutFile $wvSetup -UseBasicParsing -TimeoutSec 120
            Start-Process $wvSetup -ArgumentList '/silent /install' -Wait
        } catch {
            Say "לא הצלחתי להתקין את רכיב הדפדפן. מתקינים אותו ידנית מ:`nhttps://go.microsoft.com/fwlink/p/?LinkId=2124703`n`nואחר כך מפעילים את התוכנה." 'Warning'
        }
    }

    # בלי השהיה של תוכנות ההפעלה בכניסה, כדי שהתוכנה תעלה לפני שאפשר לעשות משהו אחר
    $serialize = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Serialize'
    EnsureKey $serialize
    Set-ItemProperty $serialize StartupDelayInMSec 0 -Type DWord

    # ---- קוד כיתה: מגרסה 43 לא שואלים. המחשב מתחבר לבד לכיתה של המורה (47933), וקוד היציאה הוא קוד המורה. ----
    # (מי שצריך כיתה אחרת: יציאה עם קוד המורה, ושם "החלפת כיתה".)
    $code = '47933'
    # התקנה מחדש על מחשב שכבר מחובר לכיתה אחרת (כיתת בדיקה) משאירה אותו בה
    $old = [string](Get-ItemProperty 'HKCU:\Software\KolKiosk' -Name ClassCode -ErrorAction SilentlyContinue).ClassCode -replace '\D', ''
    if ($old) { $code = $old }
    $className = ''
    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor 3072
        $r = Invoke-WebRequest -Uri "$DbUrl/classes/$code/state/name.json" -UseBasicParsing -TimeoutSec 15
        $name = (New-Object System.Web.Script.Serialization.JavaScriptSerializer).DeserializeObject([Text.Encoding]::UTF8.GetString($r.RawContentStream.ToArray()))
        if ($name) { $className = [string]$name }
    } catch { }
    EnsureKey 'HKCU:\Software\KolKiosk'
    Set-ItemProperty 'HKCU:\Software\KolKiosk' ClassCode $code

    # ---- הפעלה אוטומטית: מחשב של כיתה תמיד; בלי כיתה – שואלים ----
    $run = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
    EnsureKey $run
    if ($code) {
        Set-ItemProperty $run KolKiosk "`"$exe`""
        $auto = 'התוכנה תיפתח לבד בכל כניסה למחשב.'
    } else {
        Remove-ItemProperty $run KolKiosk -ErrorAction SilentlyContinue
        $auto = 'התוכנה לא תיפתח לבד. פותחים אותה מהקיצור בשולחן העבודה.'
    }

    $cls = if ($className) { "המחשב מחובר לכיתה `"$className`" ($code)." } elseif ($code) { "קוד הכיתה $code נשמר (לא נבדק מול השרת)." } else { 'המחשב יעבוד בלי שליטת מורה.' }
    Say "ההתקנה הסתיימה.`n`n$cls`n$auto`n`nהתוכנה נפתחת עכשיו."
    Start-Process $exe
} catch {
    Say "ההתקנה נכשלה:`n$($_.Exception.Message)" 'Error'
}
