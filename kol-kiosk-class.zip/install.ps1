﻿# התקנת "הקול החמישי – כיתה". מריצים דרך install.cmd.
# שלב 1 (בלי הרשאות): שומר מי המשתמש שהריץ (התלמיד) ומבקש הרשאת מנהל.
# שלב 2 (כמנהל): מתקין לכל המחשב, ומגדיר את חשבון התלמיד גם אם המנהל שאישר הוא משתמש אחר.
param([string]$TargetSid, [string]$TargetUser)

$DbUrl = 'https://kol-kiosk-class-default-rtdb.europe-west1.firebasedatabase.app'
Add-Type -AssemblyName System.Windows.Forms, Microsoft.VisualBasic, System.Web.Extensions
$Title = 'הקול החמישי – כיתה'
$Rtl = [System.Windows.Forms.MessageBoxOptions]::RtlReading -bor [System.Windows.Forms.MessageBoxOptions]::RightAlign

function Say([string]$text, [string]$icon = 'Information') {
    [void][System.Windows.Forms.MessageBox]::Show($text, $Title, 'OK', $icon, 'Button1', $Rtl)
}
function AskYesNo([string]$text) {
    return [System.Windows.Forms.MessageBox]::Show($text, $Title, 'YesNo', 'Question', 'Button1', $Rtl) -eq 'Yes'
}

$me = [Security.Principal.WindowsIdentity]::GetCurrent()
$isAdmin = (New-Object Security.Principal.WindowsPrincipal $me).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $TargetSid) { $TargetSid = $me.User.Value; $TargetUser = $me.Name }
if (-not $isAdmin) {
    try {
        Start-Process powershell -Verb RunAs -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File',
            "`"$PSCommandPath`"", '-TargetSid', $TargetSid, '-TargetUser', "`"$TargetUser`"")
    } catch {
        Say "ההתקנה צריכה הרשאת מנהל. מריצים שוב את install.cmd ומאשרים את חלון ההרשאה." 'Warning'
    }
    exit
}

try {
    $ErrorActionPreference = 'Stop'
    $src = Join-Path $PSScriptRoot 'KolKiosk.exe'
    if (-not (Test-Path $src)) { throw "הקובץ KolKiosk.exe לא נמצא ליד ההתקנה. חלצו את כל קובץ ה-ZIP לתיקייה ונסו שוב." }

    # ---- התוכנה: לכל המחשב ----
    Get-Process KolKiosk -ErrorAction SilentlyContinue | Stop-Process -Force
    Start-Sleep -Milliseconds 500
    $dir = Join-Path $env:ProgramFiles 'KolKiosk'
    $exe = Join-Path $dir 'KolKiosk.exe'
    New-Item -ItemType Directory -Force $dir | Out-Null
    Copy-Item $src $exe -Force
    Unblock-File $exe

    $ws = New-Object -ComObject WScript.Shell
    $lnk = $ws.CreateShortcut((Join-Path ([Environment]::GetFolderPath('CommonDesktopDirectory')) 'הקול החמישי - כיתה.lnk'))
    $lnk.TargetPath = $exe
    $lnk.WorkingDirectory = $dir
    $lnk.IconLocation = "$exe,0"
    $lnk.Save()

    # ---- חשבון התלמיד (הענף שלו ב-HKEY_USERS טעון, כי הוא מחובר עכשיו) ----
    $hku = "Registry::HKEY_USERS\$TargetSid"
    if (-not (Test-Path $hku)) { throw "לא נמצא חשבון המשתמש $TargetUser. מריצים את install.cmd מתוך החשבון של התלמיד." }
    function EnsureKey([string]$path) { if (-not (Test-Path $path)) { New-Item -Path $path -Force | Out-Null } }

    # הסרת גרסה ישנה שהותקנה לתיקיית המשתמש
    $userProfile = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList\$TargetSid" -ErrorAction SilentlyContinue).ProfileImagePath
    if ($userProfile) {
        Remove-Item (Join-Path $userProfile 'AppData\Local\KolKiosk\KolKiosk.exe') -Force -ErrorAction SilentlyContinue
        Remove-Item (Join-Path $userProfile 'Desktop\הקול החמישי - כיתה.lnk') -Force -ErrorAction SilentlyContinue
    }

    # רשות לתוכנה לכבות את מנהל המשימות של התלמיד בזמן שהיא פתוחה (ולהחזיר אותו ביציאה)
    $policy = "$hku\Software\Microsoft\Windows\CurrentVersion\Policies\System"
    EnsureKey $policy
    $acl = Get-Acl $policy
    $sid = New-Object Security.Principal.SecurityIdentifier $TargetSid
    $rule = New-Object Security.AccessControl.RegistryAccessRule($sid, 'SetValue,QueryValues', 'Allow')
    $acl.AddAccessRule($rule)
    Set-Acl $policy $acl

    # בלי השהיה של תוכנות ההפעלה בכניסה, כדי שהתוכנה תעלה לפני שאפשר לעשות משהו אחר
    $serialize = "$hku\Software\Microsoft\Windows\CurrentVersion\Explorer\Serialize"
    EnsureKey $serialize
    Set-ItemProperty $serialize StartupDelayInMSec 0 -Type DWord

    # ---- קוד כיתה ----
    $code = ''
    $className = ''
    while ($true) {
        $code = [Microsoft.VisualBasic.Interaction]::InputBox(
            "קוד כיתה מלוח הבקרה של המורה (5 ספרות).`n`nמשאירים ריק = בלי שליטת מורה (האתר תמיד פתוח).",
            $Title, $code) -replace '\D', ''
        if (-not $code) { break }
        try {
            [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor 3072
            $r = Invoke-WebRequest -Uri "$DbUrl/classes/$code/state/name.json" -UseBasicParsing -TimeoutSec 20
            $name = (New-Object System.Web.Script.Serialization.JavaScriptSerializer).DeserializeObject([Text.Encoding]::UTF8.GetString($r.RawContentStream.ToArray()))
            if ($name) { $className = [string]$name; break }
            if (-not (AskYesNo "קוד הכיתה $code לא נמצא.`n`nלהקליד קוד אחר?")) { $code = ''; break }
        } catch {
            Say "לא הצלחתי להתחבר לשרת הכיתה כדי לבדוק את הקוד.`nייתכן שאין אינטרנט, או שסינון האינטרנט (רימון, נטפרי וכו') חוסם את firebasedatabase.app.`n`nהקוד יישמר בכל זאת. אם המחשבים יציגו `"אין חיבור לשרת הכיתה`", צריך לבקש מהסינון לפתוח את firebasedatabase.app ואת yudataub.github.io." 'Warning'
            break
        }
    }
    EnsureKey 'HKLM:\SOFTWARE\KolKiosk'
    Set-ItemProperty 'HKLM:\SOFTWARE\KolKiosk' ClassCode $code
    EnsureKey "$hku\Software\KolKiosk"
    Set-ItemProperty "$hku\Software\KolKiosk" ClassCode $code

    # ---- קוד יציאה למחשב (בלעדיו מורה שהוריד את התוכנה מהאתר לא יכול לצאת ממנה) ----
    $hasExit = [bool](Get-ItemProperty 'HKLM:\SOFTWARE\KolKiosk' -Name ExitHash -ErrorAction SilentlyContinue)
    while ($true) {
        $prompt = "קוד יציאה למחשב הזה (לפחות 4 ספרות או אותיות).`n`nאיתו המורה יוצא מהתוכנה: כפתור `"יציאה (מורה)`" או Ctrl+Shift+Q.`nלא למסור לתלמידים!"
        if ($hasExit) { $prompt += "`n`nמשאירים ריק = להשאיר את הקוד הקיים." }
        $exitCode = ([Microsoft.VisualBasic.Interaction]::InputBox($prompt, $Title, '')).Trim()
        if (-not $exitCode -and $hasExit) { break }
        if ($exitCode.Length -ge 4) {
            $kdf = New-Object Security.Cryptography.Rfc2898DeriveBytes(
                [Text.Encoding]::UTF8.GetBytes($exitCode), [Text.Encoding]::UTF8.GetBytes('kolkiosk-local|'), 100000)
            $hex = -join ($kdf.GetBytes(32) | ForEach-Object { $_.ToString('x2') })
            Set-ItemProperty 'HKLM:\SOFTWARE\KolKiosk' ExitHash $hex
            break
        }
        if (-not $exitCode -and (AskYesNo "בלי קוד יציאה אי אפשר לצאת מהתוכנה.`n`nלבטל את ההתקנה?")) { throw 'ההתקנה בוטלה.' }
        if ($exitCode) { Say 'צריך קוד יציאה של לפחות 4 תווים.' 'Warning' }
    }

    # ---- הפעלה אוטומטית ----
    $run = "$hku\Software\Microsoft\Windows\CurrentVersion\Run"
    EnsureKey $run
    $user = ($TargetUser -split '\\')[-1]
    if (AskYesNo "להפעיל את התוכנה אוטומטית בכל כניסה של המשתמש `"$user`" למחשב?") {
        Set-ItemProperty $run KolKiosk "`"$exe`""
        $auto = 'התוכנה תיפתח לבד בכל כניסה למחשב.'
    } else {
        Remove-ItemProperty $run KolKiosk -ErrorAction SilentlyContinue
        $auto = 'התוכנה לא תיפתח לבד. פותחים אותה מהקיצור בשולחן העבודה.'
    }

    $cls = if ($className) { "המחשב מחובר לכיתה `"$className`" ($code)." } elseif ($code) { "קוד הכיתה $code נשמר (לא נבדק מול השרת)." } else { 'המחשב יעבוד בלי שליטת מורה.' }
    Say "ההתקנה הסתיימה.`n`n$cls`n$auto`n`nבשולחן העבודה יש קיצור: `"הקול החמישי - כיתה`"."
} catch {
    Say "ההתקנה נכשלה:`n$($_.Exception.Message)" 'Error'
}
