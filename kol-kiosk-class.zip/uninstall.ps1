﻿# הסרת "הקול החמישי – כיתה" מהחשבון של המשתמש שמריץ. לא צריך הרשאת מנהל.
# (התקנה ישנה לכל המחשב, ב-Program Files, נמחקת רק אם מריצים כמנהל.)

Add-Type -AssemblyName System.Windows.Forms
$Title = 'הקול החמישי – כיתה'
$Rtl = [System.Windows.Forms.MessageBoxOptions]::RtlReading -bor [System.Windows.Forms.MessageBoxOptions]::RightAlign
function Say([string]$text, [string]$icon = 'Information') {
    [void][System.Windows.Forms.MessageBox]::Show($text, $Title, 'OK', $icon, 'Button1', $Rtl)
}

try {
    Get-Process KolKiosk -ErrorAction SilentlyContinue | Where-Object { $_.SessionId -eq (Get-Process -Id $PID).SessionId } |
        Stop-Process -Force -ErrorAction SilentlyContinue
    Start-Sleep -Milliseconds 500
    Remove-ItemProperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run' KolKiosk -ErrorAction SilentlyContinue
    Remove-ItemProperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\System' DisableTaskMgr -ErrorAction SilentlyContinue
    Remove-ItemProperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Serialize' StartupDelayInMSec -ErrorAction SilentlyContinue
    if (Test-Path 'HKCU:\Software\KolKiosk') { Remove-Item 'HKCU:\Software\KolKiosk' -Recurse -Force }
    Remove-Item (Join-Path ([Environment]::GetFolderPath('Desktop')) 'הקול החמישי - כיתה.lnk') -Force -ErrorAction SilentlyContinue
    $data = Join-Path $env:LOCALAPPDATA 'KolKiosk'
    if (Test-Path $data) { Remove-Item $data -Recurse -Force -ErrorAction SilentlyContinue }

    # שאריות של התקנה ישנה לכל המחשב (רק כמנהל)
    $me = [Security.Principal.WindowsIdentity]::GetCurrent()
    if ((New-Object Security.Principal.WindowsPrincipal $me).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        if (Test-Path 'HKLM:\SOFTWARE\KolKiosk') { Remove-Item 'HKLM:\SOFTWARE\KolKiosk' -Recurse -Force -ErrorAction SilentlyContinue }
        Remove-Item (Join-Path ([Environment]::GetFolderPath('CommonDesktopDirectory')) 'הקול החמישי - כיתה.lnk') -Force -ErrorAction SilentlyContinue
        $old = Join-Path $env:ProgramFiles 'KolKiosk'
        if (Test-Path $old) { Remove-Item $old -Recurse -Force -ErrorAction SilentlyContinue }
    }
    Say 'התוכנה הוסרה מהחשבון הזה.'
} catch {
    Say "ההסרה נכשלה:`n$($_.Exception.Message)" 'Error'
}
