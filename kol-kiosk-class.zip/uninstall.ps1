﻿# הסרת "הקול החמישי – כיתה". מריצים דרך uninstall.cmd (מבקש הרשאת מנהל, ומנקה גם את חשבון התלמיד שהריץ).
param([string]$TargetSid, [string]$TargetUser)

Add-Type -AssemblyName System.Windows.Forms
$Title = 'הקול החמישי – כיתה'
$Rtl = [System.Windows.Forms.MessageBoxOptions]::RtlReading -bor [System.Windows.Forms.MessageBoxOptions]::RightAlign
function Say([string]$text, [string]$icon = 'Information') {
    [void][System.Windows.Forms.MessageBox]::Show($text, $Title, 'OK', $icon, 'Button1', $Rtl)
}

$me = [Security.Principal.WindowsIdentity]::GetCurrent()
$isAdmin = (New-Object Security.Principal.WindowsPrincipal $me).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $TargetSid) { $TargetSid = $me.User.Value; $TargetUser = $me.Name }
if (-not $isAdmin) {
    try {
        Start-Process powershell -Verb RunAs -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File',
            "`"$PSCommandPath`"", '-TargetSid', $TargetSid, '-TargetUser', "`"$TargetUser`"")
    } catch { Say 'ההסרה צריכה הרשאת מנהל.' 'Warning' }
    exit
}

try {
    Get-Process KolKiosk -ErrorAction SilentlyContinue | Stop-Process -Force
    Start-Sleep -Milliseconds 500
    $hku = "Registry::HKEY_USERS\$TargetSid"
    Remove-ItemProperty "$hku\Software\Microsoft\Windows\CurrentVersion\Run" KolKiosk -ErrorAction SilentlyContinue
    $policy = "$hku\Software\Microsoft\Windows\CurrentVersion\Policies\System"
    Remove-ItemProperty $policy DisableTaskMgr -ErrorAction SilentlyContinue
    # מחזירים את ההרשאה שההתקנה נתנה לתלמיד על מפתח המדיניות
    if (Test-Path $policy) {
        $acl = Get-Acl $policy
        $sid = New-Object Security.Principal.SecurityIdentifier $TargetSid
        $rule = New-Object Security.AccessControl.RegistryAccessRule($sid, 'SetValue,QueryValues', 'Allow')
        if ($acl.RemoveAccessRule($rule)) { Set-Acl $policy $acl }
    }
    Remove-ItemProperty "$hku\Software\Microsoft\Windows\CurrentVersion\Explorer\Serialize" StartupDelayInMSec -ErrorAction SilentlyContinue
    if (Test-Path "$hku\Software\KolKiosk") { Remove-Item "$hku\Software\KolKiosk" -Recurse -Force }
    if (Test-Path 'HKLM:\SOFTWARE\KolKiosk') { Remove-Item 'HKLM:\SOFTWARE\KolKiosk' -Recurse -Force }
    Remove-Item (Join-Path ([Environment]::GetFolderPath('CommonDesktopDirectory')) 'הקול החמישי - כיתה.lnk') -Force -ErrorAction SilentlyContinue
    $dir = Join-Path $env:ProgramFiles 'KolKiosk'
    if (Test-Path $dir) { Remove-Item $dir -Recurse -Force }
    $userProfile = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList\$TargetSid" -ErrorAction SilentlyContinue).ProfileImagePath
    if ($userProfile) {
        Remove-Item (Join-Path $userProfile 'Desktop\הקול החמישי - כיתה.lnk') -Force -ErrorAction SilentlyContinue
        $data = Join-Path $userProfile 'AppData\Local\KolKiosk'
        if (Test-Path $data) { Remove-Item $data -Recurse -Force -ErrorAction SilentlyContinue }
    }
    Say 'התוכנה הוסרה, ומנהל המשימות חזר לפעול.'
} catch {
    Say "ההסרה נכשלה:`n$($_.Exception.Message)" 'Error'
}
