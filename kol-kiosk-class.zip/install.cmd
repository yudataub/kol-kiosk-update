@echo off
chcp 65001 >nul
if not exist "%~dp0install.ps1" (echo Please extract the ZIP file first, then run install.cmd again. & pause & exit /b 1)
if not exist "%~dp0KolKiosk.exe" (echo Please extract the ZIP file first, then run install.cmd again. & pause & exit /b 1)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
